# team11package
This package is for use of team 11 and team 11 only.

## building this package locally
'python setup.py sdist'

## installing this package from GITHUB
'pip install git+<'url from git'>

## updatig this package from GITHUB
'pip install --upgrade git+<'url from git'>